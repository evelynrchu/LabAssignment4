function addition() {
	var txt1 = document.getElementById("inputone").value;
	var txt2 = document.getElementById("inputtwo").value;
	var int1 = parseInt(txt1);
	var int2 = parseInt(txt2);
	var result = int1 + int2;
	
	document.getElementById("output").value = result;
}
		
function subtraction() {
	var txt1 = document.getElementById("inputone").value;
	var txt2 = document.getElementById("inputtwo").value;
	var int1 = parseInt(txt1);
	var int2 = parseInt(txt2);
	var result = int1 - int2;
	
	document.getElementById("output").value = result;
}

function multiplication() {
	var txt1 = document.getElementById("inputone").value;
	var txt2 = document.getElementById("inputtwo").value;
	var int1 = parseInt(txt1);
	var int2 = parseInt(txt2);
	var result = (txt1)*(txt2);
	
	document.getElementById("output").value = result;
}

function division() {
	var txt1 = document.getElementById("inputone").value;
	var txt2 = document.getElementById("inputtwo").value;
	var int1 = parseInt(txt1);
	var int2 = parseInt(txt2);
	var result = (int1/int2);
	
	document.getElementById("output").value = result;
}